How to use
=============

1.Click on the index.html
(By default it will open "Manage Users" page)
2.Click on "Hamburger icon" on top left to see available options.
3.Click on any available option.
    I.Manage Users
    (Add user form will be shown here with required validations)
    II.Show users
    (A table of users will be displyed here)
=======================================OR===============================

[a link](https://kishanmund.github.io/MIC-Project/)

click on this link to visit it on the web.
